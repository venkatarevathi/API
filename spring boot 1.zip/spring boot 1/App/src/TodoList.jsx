import { useState } from "react";

function TodoList() {
  const [task, setTask] = useState("");            // Input for main task
  const [tasks, setTasks] = useState([]);          // List of tasks with subtasks
  const [subtaskInput, setSubtaskInput] = useState(""); // Input for subtask
  const [activeTaskIndex, setActiveTaskIndex] = useState(null); // Task to which subtask is being added

  // Add a new task
  const addTask = () => {
    if (task.trim() !== "") {
      setTasks([...tasks, { name: task, subtasks: [] }]);
      setTask("");
    }
  };

  // Delete a main task
  const deleteTask = (index) => {
    const updatedTasks = tasks.filter((_, i) => i !== index);
    setTasks(updatedTasks);
  };

  // Add a subtask to a specific task
  const addSubtask = () => {
    if (subtaskInput.trim() !== "" && activeTaskIndex !== null) {
      const updatedTasks = [...tasks];
      updatedTasks[activeTaskIndex].subtasks.push(subtaskInput);
      setTasks(updatedTasks);
      setSubtaskInput("");
      setActiveTaskIndex(null);
    }
  };

  // Delete a specific subtask
  const deleteSubtask = (taskIndex, subtaskIndex) => {
    const updatedTasks = [...tasks];
    updatedTasks[taskIndex].subtasks = updatedTasks[taskIndex].subtasks.filter(
      (_, i) => i !== subtaskIndex
    );
    setTasks(updatedTasks);
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>My ToDoList</h2>

      <div style={styles.inputContainer}>
        <input
          type="text"
          placeholder="Enter a task"
          value={task}
          onChange={(e) => setTask(e.target.value)}
          style={styles.input}
        />
        <button onClick={addTask} style={styles.addButton}>Add Task</button>
      </div>

      <ul style={styles.list}>
        {tasks.map((taskItem, index) => (
          <li key={index} style={styles.listItem}>
            <div>
              <strong>{taskItem.name}</strong>
              <ul style={styles.subtaskList}>
                {taskItem.subtasks.map((sub, i) => (
                  <li key={i} style={styles.subtaskItem}>
                    <span>• {sub}</span>
                    <button
                      onClick={() => deleteSubtask(index, i)}
                      style={styles.subtaskDeleteButton}
                    >
                      ❌
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <button
                style={styles.subtaskButton}
                onClick={() => setActiveTaskIndex(index)}
              >
                ➕ Subtask
              </button>
              <button
                onClick={() => deleteTask(index)}
                style={styles.deleteButton}
              >
                🗑️
              </button>
            </div>
          </li>
        ))}
      </ul>

      {activeTaskIndex !== null && (
        <div style={styles.subtaskInputContainer}>
          <input
            type="text"
            placeholder="Enter subtask"
            value={subtaskInput}
            onChange={(e) => setSubtaskInput(e.target.value)}
            style={styles.input}
          />
          <button onClick={addSubtask} style={styles.addButton}>
            Add Subtask
          </button>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    width: "90%",
    maxWidth: "600px",
    margin: "50px auto",
    padding: "20px",
    borderRadius: "12px",
    backgroundColor: "#f9f9f9",
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
    fontFamily: "Arial"
  },
  heading: {
    textAlign: "center",
    marginBottom: "20px"
  },
  inputContainer: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: "15px"
  },
  subtaskInputContainer: {
    display: "flex",
    justifyContent: "space-between",
    marginTop: "20px"
  },
  input: {
    flex: 1,
    padding: "10px",
    fontSize: "16px",
    borderRadius: "5px",
    border: "1px solid #ccc",
    marginRight: "10px"
  },
  addButton: {
    padding: "10px 20px",
    backgroundColor: "teal",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer"
  },
  list: {
    listStyleType: "none",
    padding: 0
  },
  listItem: {
    background: "#fff",
    padding: "15px",
    marginBottom: "10px",
    borderRadius: "8px",
    boxShadow: "0 0 5px rgba(0,0,0,0.05)",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start"
  },
  subtaskList: {
    listStyleType: "none",
    paddingLeft: "20px",
    marginTop: "10px"
  },
  subtaskItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "5px"
  },
  deleteButton: {
    backgroundColor: "red",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    padding: "5px 10px",
    marginLeft: "10px"
  },
  subtaskDeleteButton: {
    backgroundColor: "red",
    color: "white",
    border: "none",
    borderRadius: "50%",
    cursor: "pointer",
    padding: "3px 7px",
    marginLeft: "10px"
  },
  subtaskButton: {
    backgroundColor: "blue",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    padding: "5px 10px",
    marginRight: "5px"
  }
};

export default TodoList;
