import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Login() {
  const navigate = useNavigate();
  const [form, setform] = useState({
    username: "",
    password: ""
  });

  const changedata = (e) => {
    setform({ ...form, [e.target.name]: e.target.value });
  };

  const submitform = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:4567/login", form);
      alert(response.data);
      navigate("/todolist"); // 🔁 Navigate after successful login
    } catch (err) {
      alert("Login failed. Please try again.");
    }
  };

  const containerStyle = {
    width: "100%",
    maxWidth: "400px",
    padding: "30px",
    border: "1px solid #ccc",
    borderRadius: "15px",
    boxShadow: "0 5px 15px rgba(0,0,0,0.1)",
    backgroundColor: "#f7f9fc",
    textAlign: "center",
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)"
  };

  const titleStyle = {
    color: "#333",
    marginBottom: "20px",
    fontSize: "28px"
  };

  const inputStyle = {
    width: "100%",
    padding: "12px 15px",
    margin: "10px 0",
    borderRadius: "8px",
    border: "1px solid #aaa",
    fontSize: "16px"
  };

  const buttonStyle = {
    width: "100%",
    padding: "12px",
    backgroundColor: "teal",
    color: "white",
    fontSize: "18px",
    border: "none",
    borderRadius: "8px",
    marginTop: "10px",
    cursor: "pointer",
    transition: "background 0.3s ease"
  };

  return (
   <div style={containerStyle}>
      <h1 style={titleStyle}>Login Page</h1>
      <form onSubmit={submitform}>
        <input style={inputStyle} onChange={changedata} type="text" name="username" placeholder="Enter username"/>
        <input style={inputStyle} onChange={changedata} type="password" name="password" placeholder="Enter password"/>
        <button style={buttonStyle} type="submit">Login</button>
      </form>
    </div>
  );
}

export default Login;
