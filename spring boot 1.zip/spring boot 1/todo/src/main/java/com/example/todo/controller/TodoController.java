package com.example.todo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.todo.model.Todo;
import com.example.todo.repository.TodoRepository;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
public class TodoController
{
    @Autowired
    TodoRepository tr;
    
    @GetMapping("/reg")
     String m1()
     {
         return "register";
     }
     @PostMapping("/register")
     String m2 (@RequestBody Todo t)
     {
        Todo result=this.tr.findByUsername((String) t.getUsername());
        if(result != null)
        {
            return "username exists";
        }
        this.tr.save(t);
        return "register success";

     }

      @GetMapping("/log")
     String m3()
     {
         return "login";
     }

     @PostMapping("/login")
     String m4(@RequestBody Todo t)
      {
    
        Todo result=this.tr.findByUsername((String) t.getUsername());
        if(result != null && result.getPassword().equals(t.getPassword()))
        {
            return "username exists";
        }
        this.tr.save(t);
        return "login success";

     }
    }
