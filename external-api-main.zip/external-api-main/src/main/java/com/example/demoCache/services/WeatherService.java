package com.example.demoCache.services;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class WeatherService {

    private final RestTemplate restTemplate = new RestTemplate();

    // @Value("${weather.api.key}")
    private String apiKey="44e71fd78c866dcdf957a96a8f1d9b66";

    @Cacheable("weather")
    public String getWeatherByCity(String city) {
        String url = "https://api.openweathermap.org/data/2.5/weather"
                   + "?q=" + city
                   + "&appid=" + this.apiKey
                   + "&units=metric"; // Or use 'imperial' for Fahrenheit

        try {
            ResponseEntity<Map> response = this.restTemplate.getForEntity(url, Map.class);
            if (!response.getStatusCode().is2xxSuccessful()) {
                return "Failed to get weather: " + response.getStatusCode();
            }

            Map body = response.getBody();
            if (body == null || body.isEmpty()) {
                return "Empty weather data received.";
            }

            Map main = (Map) body.get("main");
            Map weather = ((java.util.List<Map>) body.get("weather")).get(0);

            double temp = (Double) main.get("temp");
            String description = (String) weather.get("description");

            return "Current weather in " + city + ": " + temp + "°C, " + description;

        } catch (Exception e) {
            return "Error fetching weather: " + e.getMessage();
        }
    }
}



// ✅ Step-by-step: Get OpenWeatherMap API Key
// 1. Visit the OpenWeatherMap website
// 👉 https://openweathermap.org/api

// 2. Sign up for a free account
// Click on Sign Up (top right corner).

// Create an account with your email.

// Verify your email address (required).

// 3. Generate an API key
// After logging in:

// Go to: https://home.openweathermap.org/api_keys

// Click on "Create Key".

// Give it a name like MyWeatherKey.

// The key will look something like:

// Copy
// Edit
// 44e71fd78c866dcdf957a96a8f1d9b66
// 4. Use the key in your Java code or application.properties
// ✅ In your Java code (you already do this):

// java
// Copy
// Edit
// private String apiKey = "44e71fd78c866dcdf957a96a8f1d9b66";
// 💡 Recommended: Use application.properties for security:

// src/main/resources/application.properties:

// properties
// Copy
// Edit
// weather.api.key=44e71fd78c866dcdf957a96a8f1d9b66
// Then in your service class:

// java
// Copy
// Edit
// @Value("${weather.api.key}")
// private String apiKey;
// Make sure your class is annotated with @Service (which it is), and Spring will automatically inject the value.

// 🌦️ Sample API Request (what your code builds):
// http
// Copy
// Edit
// https://api.openweathermap.org/data/2.5/weather?q=London&appid=YOUR_API_KEY&units=metric
// It returns JSON like:

// json
// Copy
// Edit
// {
//   "main": {
//     "temp": 28.34
//   },
//   "weather": [
//     {
//       "description": "clear sky"
//     }
//   ]
// }