import React, { useState } from 'react';
import axios from 'axios';

export default function App() {
  const [query, setQuery] = useState('');
  const [region, setRegion] = useState('Asia/Kolkata');
  const [city, setCity] = useState('');
  const [dataResult, setDataResult] = useState('');
  const [timeResult, setTimeResult] = useState('');
  const [weatherResult, setWeatherResult] = useState('');

  const handleGetData = async () => {
    try {
      const res = await axios.get(`http://localhost:8080/data?query=${query}`);
      setDataResult(res.data);
    } catch (err) {
      setDataResult('Error fetching data');
    }
  };

  const handleGetTime = async () => {
    try {
      const res = await axios.get(`http://localhost:8080/time?region=${region}`);
      console.log(res)
      setTimeResult(res.data);
    } catch (err) {
      setTimeResult('Error fetching time');
    }
  };

  const handleGetWeather = async () => {
    try {
      const res = await axios.get(`http://localhost:8080/city/${city}`);
      console.log(res)
      setWeatherResult(res.data);
    } catch (err) {
      setWeatherResult('Error fetching weather');
    }
  };

  return (
    <div className="min-h-screen p-8 bg-gray-100 space-y-8">
      <h1 className="text-2xl font-bold text-center">Weather & Time API Client</h1>

      <div className="bg-white p-4 rounded shadow space-y-2">
        <h2 className="font-semibold">Get Cached Data</h2>
        <input
          className="border p-2 w-full"
          placeholder="Enter query"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button onClick={handleGetData} className="bg-blue-500 text-white px-4 py-2 rounded">
          Fetch Data
        </button>
        <p className="mt-2">Result: {dataResult}</p>
      </div>

      <div className="bg-white p-4 rounded shadow space-y-2">
        <h2 className="font-semibold">Get Time by Region</h2>
        <input
          className="border p-2 w-full"
          placeholder="e.g., Asia/Kolkata"
          value={region}
          onChange={(e) => setRegion(e.target.value)}
        />
        <button onClick={handleGetTime} className="bg-green-500 text-white px-4 py-2 rounded">
          Fetch Time
        </button>
        <p className="mt-2">Time: {timeResult}</p>
      </div>

      <div className="bg-white p-4 rounded shadow space-y-2">
        <h2 className="font-semibold">Get Weather by City</h2>
        <input
          className="border p-2 w-full"
          placeholder="Enter city name"
          value={city}
          onChange={(e) => setCity(e.target.value)}
        />
        <button onClick={handleGetWeather} className="bg-purple-500 text-white px-4 py-2 rounded">
          Fetch Weather
        </button>
        <p className="mt-2">Weather: {weatherResult}</p>
      </div>
    </div>
  );
}
