import { Link } from "react-router-dom"

function Home()
{
    return(
        <>
           <h1>Hii i am at Home...</h1>
           <Link to="/reg">click here to register</Link><br/>
           <Link to="/log">Login Here</Link>
        </>
    )
}
export default Home