import { useState } from "react"
import axios from "axios"

function Register()
{
    const [form,setform]=useState(
        {
            username:"",
            email:"",
            password:""
        }
    )    
    const changedata=(e) =>
    {
        setform({...form,[e.target.name]:e.target.value})
    }
    const submitform=async (e) =>
    {
        e.preventDefault();
        const response=await axios.post("http://localhost:1212/register",form)
        alert(response.data)
    }
    
    return(
        <>
           <h1>registration page </h1>
           <form onSubmit={submitform}>
               <input onChange={changedata} type="text" name="username" placeholder="create username"/><br></br>
               <input onChange={changedata} type="email" name="email" placeholder="enter email"/><br></br>
               <input onChange={changedata} type="password" name="password" placeholder="create password"/><br></br>
               <button type="submit">register</button>
           </form>
        </>
    )
}
export default Register