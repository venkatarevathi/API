import { useState } from "react"
import axios from "axios"
import { useNavigate } from "react-router-dom"

function Login()
{
    const navigate=useNavigate()
    const [form,setform]=useState(
        {
            username:"",
            password:""
        }
    )    
    const changedata=(e) =>
    {
        setform({...form,[e.target.name]:e.target.value})
    }
    const submitform=async (e) =>
    {
        e.preventDefault();
        const response=await axios.post("http://localhost:1212/login",form)
        alert(response.data)
        navigate("/admin")
    }
    
    return(
        <>
           <h1>Login page </h1>
           <form onSubmit={submitform}>
               <input onChange={changedata} type="text" name="username" placeholder="enter username"/><br></br>
               <input onChange={changedata} type="password" name="password" placeholder="enter password"/><br></br>
               <button type="submit">Login</button>
           </form>
        </>
    )
}
export default Login