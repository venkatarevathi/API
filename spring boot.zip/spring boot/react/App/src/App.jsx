import { BrowserRouter, Route, Routes } from "react-router-dom"
import Home from "./Home"
import Register from "./Register"
import Login from "./Login"
import Admin from "./admin"
import Library from "./Library"
import AddBook from "./books/AddBook"
import AuthorBook from "./books/AuthorBook"
import ViewAll from "./books/ViewAll"
import BookData from "./books/BookData"

function App()
{
  return(
    <>
    <BrowserRouter>
        <Routes>
           <Route path="/" element={<Home/>}/>
           <Route path="/reg" element={<Register/>}/>
           <Route path="/log" element={<Login/>}/>
           <Route path="/admin" element={<Admin/>}/>
           <Route path="/library" element={<Library/>}/>
          <Route path="/abook" element={<AddBook/>}/>
          <Route path="/vauthorbooks" element={<AuthorBook/>}/>
           <Route path="/viewall" element={<ViewAll/>}/>
           <Route path="/bookdata" element={<BookData/>}/>
        </Routes>
      </BrowserRouter>
    </>
  )
}
export default App
