import axios from "axios"
import { useState } from "react"

function AddBook()
{
    const [form,setform] = useState(
        {
        title:"",
        author:"",
        description:""
        }
    )
    const submitform = async (e) =>
    {
        e.preventDefault()
        try{
           const response= await axios.post("http://localhost:1212/book/addbook",form)
           console.log(response)
           alert(response.data)
        }
        catch(error)
        {
            if(error.response && error.response.status === 409)
            {
                alert(error.response.data)
            }
            else
            {
                alert("something went wrong")
            }
        }
        
       

    }
    const changedata = (e) =>
    {
        setform({...form,[e.target.name]:e.target.value})

    }
    return(
        <>
        <h1>Add a Book</h1>
          <form onSubmit={submitform}>
            <input onChange={changedata} type="text" name="title" placeholder="enter title"/><br/>
            <input onChange={changedata} type="text" name="author" placeholder="enter author name"/><br/>
            <input onChange={changedata} type="text" name="description" placeholder="write about  book"/><br/>
            <button type="submit">AddBook</button>

          </form>
        </>
    )
}
export default AddBook
